﻿<#
# AUTHOR  : Victor Ashiedu
# WEBSITE : iTechguides.com
# BLOG    : iTechguides.com/blog
# CREATED : 11-03-2015 
# UPDATED : 11-03-2015 
# COMMENT : Get-UserLockoutStatus is an Advanced PowerShell function for troubleshooting persistent account lockout problems
#			The function searches all domain controllers for a user in a domain for account lockout status, Bad Password Count, 
#			Last bad password time, and When password was set last.        
#>
 
Function Get-UserLockoutStatus {

<#
.SYNOPSIS
	Get-UserLockoutStatus is an Advanced PowerShell function for troubleshooting persistent account lockout problems. 	
.DESCRIPTION
	UGet-UserLockoutStatus searches all domain controllers for a user in a domain for account lockout status, Bad Password Count,Last bad password time, and When password was set last. Useful for troubleshooting persistent account lockout issues. The function also lists the Domain Controllers and the Site they belong. The information listed above is displayed for the user for each Domain Controller.
.PARAMETER TargetUserName
	Specifies Active Directory user name to query for account lockout status
	has Active Directory web services installed. It is recomended to enter the TargetUserName in the FQDN format for example TargetUserName.co.uk instead of TargetUserName
.PARAMETER TargetDomainName
	Specifies the Active Directory domain to query. 
	
.EXAMPLE
	To get account lock out status for test1.user1 in the 70411Lab.com Domain
	PS Z:\> Get-UserLockoutStatus -TargetDomainName 70411Lab.com Domain -TargetUserName test1.use1
	DC Name Site                    	User State Bad Pwd Count Last Bad Pwd        Pwd Last Set         Lockout Time       
	------- ----                    	---------- ------------- ------------        ------------         ------------       
	70411DC1  Default-First-Site-Name 	Locked                 5 09/03/2015 15:37:31 Password Must Change 09/03/2015 15:37:31
	70411DC2  Default-First-Site-Name 	Locked                 0 None                Password Must Change 09/03/2015 15:37:31
	70411DC3  Default-First-Site-Name 	Locked                 0 None                Password Must Change 09/03/2015 15:37:31
	70411DC4  Default-First-Site-Name 	Locked                 5 09/03/2015 15:37:31 Password Must Change 09/03/2015 15:37:31
	
	Note: This information helps you determine how may times user entered an incorrect password (Bad Pwd Count)
	If the frequency is much, it might be that an attacker might be trying to guess the password or an application
	is attempting to log on but pasword has changed. Knowing the last date password was changed will confirm the 
	last statement. 
	
	In the last example, the user's account is currently set to "Password Must Change at Next Log on"
	
EXAMPLE
	If you enter an account that does not exist in the domain, the function returns the error below
	PS Z:\> Get-UserLockoutStatus -TargetDomainName 70411Lab.com Domain -TargetUserName test1.use
	Cannot find an object with identity: 'test1.user' under: 'DC=kingston,DC=gov,DC=uk'. Please resolve the error and try again 
	
#>

[CmdletBinding(DefaultParameterSetName='TargetUserName')]
Param
(
[Parameter(Mandatory=$true,Position=0,ParameterSetName='TargetUserName')]
[String]$TargetUserName,
[Parameter(Mandatory=$true,Position=1,ParameterSetName='TargetUserName')]
[String]$TargetDomainName		
)

BEGIN {}

PROCESS {
Write-Host "Importing Active Directory Modules and performing pre-tasks..." -ForegroundColor Cyan
#import the ActiveDirectory Module
Import-Module ActiveDirectory -WarningAction SilentlyContinue
Write-Host "Checking account lock out status for $TargetUserName" -ForegroundColor Magenta
#Get DCs in the current domain#displayed in FQDN 
Try {
$DCs = [System.DirectoryServices.ActiveDirectory.domain]::GetDomain((
(New-Object System.DirectoryServices.ActiveDirectory.DirectoryContext('Domain', $TargetDomainName)))) |							
% { $_.DomainControllers } | Select-Object name, SiteName
}
Catch [Exception]
{
Write-Host "$($_.Exception.Message) Please enter domain name in FQDN format; eg TargetDomainName.co.uk  " -ForegroundColor Red
Break
}
$UserInfo =	 
ForEach ($DC in $DCs)
{
$DCOnly = %{$DC.name} #The % sign ensures that only the server name is selected.
#If not included, it will be displayed in the format @{Name=xxx,Site=xxx}; 
#popping error when used in the Get-ADComputer command below
$DCName = (Get-ADComputer -LDAPFilter "(DNSHostName=$DCOnly)" -Server $DCOnly).Name #Get DCs in Name format, not FQDN
Try {

$dn = (Get-ADUser -Identity $TargetUserName -server $DCOnly -ErrorAction Stop).DistinguishedName

}
Catch [Exception]
{
Write-Host "$($_.Exception.Message) Please resolve the error and try again " -ForegroundColor Red
Break
}
Get-ADUser -LDAPFilter "(sAMAccountName=$TargetUserName)" -Server $DCOnly `
-Properties LockedOut,badPwdCount,LastBadPasswordAttempt,PasswordLastSet,AccountLockoutTime -ErrorAction Stop |
Select-Object @{Label = "DC Name";Expression = {$DCName}},
@{Label = "Site";Expression = {$DC.SiteName}},
@{Label = "User State";Expression = {If ($_.LockedOut -eq  'True') {'Locked'} Else {'Not Locked'}}},#get property for current lockout status
@{Label = "Bad Pwd Count";Expression = {If (($_.badPwdCount -eq '0') -or ($_.badPwdCount -eq $null)) {'0'} Else {$_.badPwdCount}}},
@{Label = "Last Bad Pwd";Expression = {If ($_.LastBadPasswordAttempt -eq $null) {'None'} Else {$_.LastBadPasswordAttempt}}},
@{Label = "Pwd Last Set";Expression = {If ($_.PasswordLastSet -eq $null) {'Password Must Change'} Else {$_.PasswordLastSet}}},
@{Label = "Lockout Time";Expression = {If ($_.AccountLockoutTime -eq $null) {'N/A'} Else {$_.AccountLockoutTime}}} 


}
If ($UserInfo)
{Write-Host "Account lock out status for $TargetUserName is diaplayed below:" -ForegroundColor Yellow}
$UserInfo | Sort-Object -Property "DC Name" | Format-Table -AutoSize

}

END {}

}
